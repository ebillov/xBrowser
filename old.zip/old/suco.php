<?php
add_action('wp_footer', 'wj_mobile_compatibility_css_suco');

function wj_mobile_compatibility_css_suco()
{
	?>
	<style type="text/css">
		<?php echo $general ?>
		.header-widget .vCard div[style] {
			text-align: right!important;
		}
		.header-widget .vCard img {
			margin-left: 3px;
		}
		.header-widget .widget.widget_text {
			margin:0;
			padding:10px 0 3px;
		}
		
		.header-widget #searchform {
			position: static!important;
		}
		
		@media (max-width: 773px) {
			
		}
		
		@media (max-width: 601px) {
			.header-widget #header #searchform {
				position: absolute;
			}
			.header-widget .mobile-button {
				position: absolute;
				right: 42px;
				top: 8px;				
			}
			.header-widget {
				text-align: center;
			}
			.header-widget .vCard div[style] {
				text-align: center!important;
			}		
			#headerwrap #searchform {
				width: 100%!important;
				text-align: center;
			}
			#header #searchform #s{
				float: none;
			}
			#footer-logo {
				position: static;
			}
		}
		
		@media (max-width: 480px) {
			.category .post-image {
			  float: none;
			}			
		}
	</style>
	<?php
}
