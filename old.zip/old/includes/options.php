<?php

function wje_settings()
{
	echo 'Test';
}