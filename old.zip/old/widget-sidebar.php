<?php
add_action('widgets_init', 'wpe_header_right_sidebar');
function wpe_header_right_sidebar(){
    register_sidebar( array(
        'name' => __( 'Header Right Widgets' ),
        'id' => 'header-right-widgets',
        'description' => __( 'Header Right Widgets', 'my_textdomain' ),
        'before_title' => '<h1>',
        'after_title' => '</h1>'
    ));
}

/*<div class="header-widget header-right"><ul class="header-right-widgets"><?php dynamic_sidebar('header-right-widgets'); ?></ul></div>*/
?>